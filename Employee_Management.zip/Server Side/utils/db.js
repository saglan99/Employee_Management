import mysql from 'mysql2'

const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "admin",
    database: "employees"
})

con.connect(function(err) {
    if(err) {
        console.log(err);
        console.log("connection error")
    } else {
        console.log("Connected")
    }
})

export default con;

