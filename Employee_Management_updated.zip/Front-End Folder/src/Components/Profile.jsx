import React from "react";

const Profile = () => {
  return <div>Work in progress....</div>;
};

export default Profile;
